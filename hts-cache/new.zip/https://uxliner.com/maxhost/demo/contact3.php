<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>MaxHot - Professional Web Hosting Responsive HTML5 Template</title>

<!-- Favicon -->
<link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png">

<!-- Google fonts - witch you want to use - (rest you can just remove) -->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,500,400italic,500italic,700,900' rel='stylesheet' type='text/css'>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->

<!-- Bootstrap -->
<link href="css/bootstrap.min.css" rel="stylesheet">

<!--  CSS STYLES  -->
<link rel="stylesheet" href="css/style.css" type="text/css" />
<link rel="stylesheet" href="css/reset.css" type="text/css" />
<link rel="stylesheet" href="css/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="css/Simple-Line-Icons-Webfont/simple-line-icons.css"/>
<link rel="stylesheet" href="css/et-line-font/et-line-font.css">

<!-- Responsive Devices Styles -->
<link rel="stylesheet" media="screen" href="css/responsive-leyouts.css" type="text/css" />

<!-- Mega Menu -->
<link href="js/mainmenu/menu.css" rel="stylesheet">

<!-- forms -->
<link rel="stylesheet" href="js/form/css/sky-forms.css" type="text/css" media="all">

<!-- Remove the below comments to use your color option -->
<!--<link rel="stylesheet" href="css/colors/orange.css" />-->
<!--<link rel="stylesheet" href="css/colors/blue.css" />-->
<!--<link rel="stylesheet" href="css/colors/lightgreen.css" />-->
<!--<link rel="stylesheet" href="css/colors/lightblue.css" />-->
<!--<link rel="stylesheet" href="css/colors/bluesea.css" />-->
<!--<link rel="stylesheet" href="css/colors/lightred.css" />-->
<!--<link rel="stylesheet" href="css/colors/sea.css" />-->
<!--<link rel="stylesheet" href="css/colors/red.css" />-->
<!--<link rel="stylesheet" href="css/colors/lightorange.css" />-->
<!--<link rel="stylesheet" href="css/colors/green.css" />-->

<!-- just remove the below comments witch bg patterns you want to use -->
<!--<link rel="stylesheet" href="css/bg-patterns/pattern-default.css" />-->
<!--<link rel="stylesheet" href="css/bg-patterns/pattern-one.css" />-->
<!--<link rel="stylesheet" href="css/bg-patterns/pattern-two.css" />-->
<!--<link rel="stylesheet" href="css/bg-patterns/pattern-three.css" />-->
<!--<link rel="stylesheet" href="css/bg-patterns/pattern-four.css" />-->
<!--<link rel="stylesheet" href="css/bg-patterns/pattern-five.css" />-->
<!--<link rel="stylesheet" href="css/bg-patterns/pattern-six.css" />-->
<!--<link rel="stylesheet" href="css/bg-patterns/pattern-seven.css" />-->
<!--<link rel="stylesheet" href="css/bg-patterns/pattern-eight.css" />-->
<!--<link rel="stylesheet" href="css/bg-patterns/pattern-nine.css" />-->
<!--<link rel="stylesheet" href="css/bg-patterns/pattern-ten.css" />-->
<!--<link rel="stylesheet" href="css/bg-patterns/pattern-eleven.css" />-->
<!--<link rel="stylesheet" href="css/bg-patterns/pattern-twelve.css" />-->
<!--<link rel="stylesheet" href="css/bg-patterns/pattern-thirteen.css" />-->
<!--<link rel="stylesheet" href="css/bg-patterns/pattern-fourteen.css" />-->

<!-- Style Switcher -->
<link rel = "stylesheet" media = "screen" href = "js/style-switcher/color-switcher.css" />
<!-- Style Switcher Colors -->
<link rel="alternate stylesheet" type="text/css" href="css/colors/orange.css" title="orange" />
<link rel="alternate stylesheet" type="text/css" href="css/colors/blue.css" title="blue" />
<link rel="alternate stylesheet" type="text/css" href="css/colors/lightgreen.css" title="lightgreen" />
<link rel="alternate stylesheet" type="text/css" href="css/colors/lightblue.css" title="lightblue" />
<link rel="alternate stylesheet" type="text/css" href="css/colors/sea.css" title="sea" />
<link rel="alternate stylesheet" type="text/css" href="css/colors/lightred.css" title="lightred" />
<link rel="alternate stylesheet" type="text/css" href="css/colors/bluesea.css" title="bluesea" />
<link rel="alternate stylesheet" type="text/css" href="css/colors/red.css" title="red" />
<link rel="alternate stylesheet" type="text/css" href="css/colors/lightorange.css" title="lightorange" />
<link rel="alternate stylesheet" type="text/css" href="css/colors/green.css" title="green" />
<link rel="alternate stylesheet" type="text/css" href="css/bg-patterns/pattern-default.css" title="pattern-default" />
<link rel="alternate stylesheet" type="text/css" href="css/bg-patterns/pattern-one.css" title="pattern-one" />
<link rel="alternate stylesheet" type="text/css" href="css/bg-patterns/pattern-two.css" title="pattern-two" />
<link rel="alternate stylesheet" type="text/css" href="css/bg-patterns/pattern-three.css" title="pattern-three" />
<link rel="alternate stylesheet" type="text/css" href="css/bg-patterns/pattern-four.css" title="pattern-four" />
<link rel="alternate stylesheet" type="text/css" href="css/bg-patterns/pattern-five.css" title="pattern-five" />
<link rel="alternate stylesheet" type="text/css" href="css/bg-patterns/pattern-six.css" title="pattern-six" />
<link rel="alternate stylesheet" type="text/css" href="css/bg-patterns/pattern-seven.css" title="pattern-seven" />
<link rel="alternate stylesheet" type="text/css" href="css/bg-patterns/pattern-eight.css" title="pattern-eight" />
<link rel="alternate stylesheet" type="text/css" href="css/bg-patterns/pattern-nine.css" title="pattern-nine" />
<link rel="alternate stylesheet" type="text/css" href="css/bg-patterns/pattern-ten.css" title="pattern-ten" />
<link rel="alternate stylesheet" type="text/css" href="css/bg-patterns/pattern-eleven.css" title="pattern-eleven" />
<link rel="alternate stylesheet" type="text/css" href="css/bg-patterns/pattern-twelve.css" title="pattern-twelve" />
<link rel="alternate stylesheet" type="text/css" href="css/bg-patterns/pattern-thirteen.css" title="pattern-thirteen" />
<link rel="alternate stylesheet" type="text/css" href="css/bg-patterns/pattern-fourteen.css" title="pattern-fourteen" />
</head>
<body>
<div class="site-wrapper">
  <div class="header-top black-bg-light">
    <div class="container">
      <div class="col-md-6 col-sm-6 nopadding font-bold">
        <ul class="social-icons style-two">
          <li><a href="#"><i class="fa fa-facebook"></i></a></li>
          <li><a href="#"><i class="fa fa-twitter"></i></a></li>
          <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
          <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
          <li><a href="#"><i class="fa fa-flickr"></i></a></li>
          <li><a href="#"><i class="fa fa-youtube"></i></a></li>
        </ul>
      </div>
      <div class="col-md-6 col-sm-6 no-dis-phone nopadding text-right font13 uppercase"> <a href="#"><i class="fa fa-comments"></i> Live Chat</a> <span>/</span> <a href="#"><i class="fa fa-envelope"></i> E-mail Us</a> <span>/</span> <i class="fa fa-phone"></i> (123) 456 7890 <span>/</span> <a href="#" class="login-btn">LOGIN</a><a href="#" class="register-btn">Register</a></div>
    </div>
  </div>
  <!-- topnav end -->
  
  <header class="header whitebg headr-style-1">
    <div class="container"> 
      <!-- Menu -->
      <div class="navbar yamm navbar-default">
        <div class="container">
          <div class="navbar-header">
              <button type="button" data-toggle="collapse" data-target="#navbar-collapse-1" class="navbar-toggle"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
              <a href="index.html" class="navbar-brand logo"></a> </div>
          <div id="navbar-collapse-1" class="navbar-collapse collapse pull-right dark-color nopadding">
            <nav>
              <ul class="nav navbar-nav">
                <!-- Classic list -->
                <li class="dropdown"><a href="index.html" class="dropdown-toggle">Home</a>
                  <ul role="menu" class="dropdown-menu">
                    <li><a href="index.html">Home Style 1</a></li>
                    <li><a href="index2.html">Home Style 2</a></li>
                    <li><a href="index3.html">Home Style 3</a></li>
                    <li><a href="index4.html">Home Style 4</a></li>
                    <li><a href="index5.html">Home Style 5</a></li>
                    <li><a href="index6.html">Home Style 6</a></li>
                    <li><a href="index7.html">Home Style 7</a></li>
                    <li><a href="index8.html">Home Style 8</a></li>
<li><a href="index9.html">Home Style 9</a></li>
<li><a href="index10.html">Home Style 10</a></li>
                  </ul>
                </li>
                <li class="dropdown"><a href="domain-search.html">Domains</a></li>
                <li class="dropdown"><a href="hosting-services.html">Hosting</a></li>
                <li class="dropdown"><a href="about.html" class="dropdown-toggle">Pages</a>
                  <ul role="menu" class="dropdown-menu">
                    <li><a href="about.html">About Style 1</a></li>
                    <li><a href="about2.html">About Style 2</a></li>
                    <li><a href="about3.html">About Style 3</a></li>
                    <li><a href="services.html">Services Style 1</a></li>
                    <li><a href="services2.html">Services Style 2</a></li>
                    <li><a href="services3.html">Services Style 3</a></li>
                    <li><a href="team.html">Our Team Style 1</a></li>
                    <li><a href="team2.html">Our Team Style 2</a></li>
                    <li><a href="faqs.html">FAQ Style 1</a></li>
                    <li><a href="faqs2.html">FAQ Style 2</a></li>
                    <li class="dropdown-submenu mul"> <a href="#" tabindex="-1">Multi Level Submenu</a>
                      <ul class="dropdown-menu" style="">
                        <li><a href="#">Menu Item 1</a></li>
                        <li><a href="#">Menu Item 2</a></li>
                        <li><a href="#">Menu Item 3</a></li>
                      </ul>
                    </li>
                  </ul>
                </li>
                <li class="dropdown yamm-fw"><a href="left-sidebar.html" class="dropdown-toggle">Features</a>
                  <ul class="dropdown-menu">
                    <li>
                      <div class="yamm-content">
                        <div class="row">
                          <ul class="col-sm-3 col-md-3 list-unstyled">
                            <li><span class="font-white">Features List</span></li>
                            <li><a href="left-sidebar.html"><i class="fa fa-angle-right"></i> Left Sidebar Page</a></li>
                            <li><a href="right-sidebar.html"><i class="fa fa-angle-right"></i> Right Sidebar Page</a></li>
                            <li><a href="left-nav.html"><i class="fa fa-angle-right"></i> Left Navigation</a></li>
                            <li><a href="right-nav.html"><i class="fa fa-angle-right"></i> Right Navigation</a></li>
                            <li><a href="login.html"><i class="fa fa-angle-right"></i> Login Form</a></li>
                            <li><a href="register.html"><i class="fa fa-angle-right"></i> Registration Form</a></li>
                          </ul>
                          <ul class="col-sm-3 col-md-3 list-unstyled">
                            <li><span class="font-white">Features List</span></li>
                            <li><a href="coming-soon.html" target="_blank"><i class="fa fa-angle-right"></i> Coming Soon</a></li>
                            <li><a href="coming-soon2.html"><i class="fa fa-angle-right"></i> Coming Soon 2</a></li>
                            <li><a href="404.html"><i class="fa fa-angle-right"></i> 404 Error Page</a></li>
                            <li><a href="#"><i class="fa fa-angle-right"></i> Mega Menu Light</a></li>
                            <li><a href="#"><i class="fa fa-angle-right"></i> Mega Menu Dark</a></li>
                            <li><a href="#"><i class="fa fa-angle-right"></i> Cross Browser Check</a></li>
                          </ul>
                          <ul class="col-sm-3 col-md-3 list-unstyled">
                            <li><span class="font-white">Features List</span></li>
                            <li><a href="#"><i class="fa fa-angle-right"></i> Premium Sliders</a></li>
                            <li><a href="#"><i class="fa fa-angle-right"></i> Diffrent Slide Shows</a></li>
                            <li><a href="#"><i class="fa fa-angle-right"></i> Video BG Effects</a></li>
                            <li><a href="#"><i class="fa fa-angle-right"></i> 100+ Feature Sections</a></li>
                            <li><a href="#"><i class="fa fa-angle-right"></i> Use for any Website</a></li>
                          </ul>
                          <div class="col-sm-3 col-md-3 list-unstyled"> 
                            <!-- Wrapper for slides -->
                            <ul class="col-sm-3 col-md-3 list-unstyled">
                              <li><span class="font-white"><strong>MaxHot</strong></span></li>
                            </ul>
                            <img src="images/site-img6.jpg" alt="" class="img-responsive"> </div>
                        </div>
                      </div>
                    </li>
                  </ul>
                </li>
                <li class="dropdown yamm-fw"><a href="accordions.html" class="dropdown-toggle">Elements</a>
                  <ul class="dropdown-menu">
                    <li>
                      <div class="yamm-content">
                        <div class="row">
                          <ul class="col-sm-3 col-md-3 list-unstyled">
                            <li><span class="font-white">Elements List</span></li>
                            <li><a href="accordions.html"><i class="fa fa-plus-circle"></i> Accordions</a></li>
                            <li><a href="image-hover.html"><i class="fa fa-picture-o"></i> Image Hovers</a></li>
                            <li><a href="buttons.html"><i class="fa fa-bars"></i> Button Styles</a></li>
                            <li><a href="call-to-action.html"><i class="fa fa-external-link-square"></i> Call to Action</a></li>
                            <li><a href="carousel-sliders.html"><i class="fa fa-eye"></i> Carousel Sliders</a></li>
                            <li><a href="columns.html"><i class="fa fa-leaf"></i> Columns</a></li>
                            <li><a href="lists.html"><i class="fa fa-list"></i> lists Styles</a></li>
                          </ul>
                          <ul class="col-sm-3 col-md-3 list-unstyled">
                            <li><span class="font-white">Elements List</span></li>
                            <li><a href="message-boxes.html"><i class="fa fa-tags"></i> Message Boxes</a></li>
                            <li><a href="animated-counters.html"><i class="fa fa-rocket"></i> Animated Counters</a></li>
                            <li><a href="pricing-tables.html"><i class="fa fa-rocket"></i> Pricing Tables</a></li>
                            <li><a href="tabs.html"><i class="fa fa-qrcode"></i> Tabs</a> </li>
                            <li><a href="typography.html"><i class="fa fa-font"></i> Typography</a> </li>
                            <li><a href="content-boxes.html"><i class="fa fa-flag"></i> Content Boxes</a> </li>
                            <li><a href="popover-tooltip.html"><i class="fa fa-paper-plane"></i> Popover &amp; Tooltip</a> </li>
                          </ul>
                          <ul class="col-sm-3 col-md-3 list-unstyled">
                            <li><span class="font-white">Elements List</span></li>
                            <li><a href="social-icons.html"><i class="fa fa-twitter"></i> Social Icons</a> </li>
                            <li><a href="flip-boxes.html"><i class="fa fa-umbrella"></i> Flip Boxes</a> </li>
                            <li><a href="progress-bars.html"><i class="fa fa-thumbs-up"></i> Progress Bars</a> </li>
                            <li><a href="dividers.html"><i class="fa fa-file-text"></i> Dividers</a> </li>
                            <li><a href="#"><i class="fa fa-external-link"></i> Free Updates</a> </li>
                          </ul>
                          <div class="col-sm-3 col-md-3 list-unstyled">
                            <ul class="col-sm-3 col-md-3 list-unstyled">
                              <li><span class="font-white"><strong>About MaxHot</strong></span></li>
                            </ul>
                            <p class="font-white">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam nisi tortor, sollicitudin eget elit et, tincidunt lobortis diam. Fusce lobortis sollicitudin metus nec consectetur. Maecenas a velit arcu. Quisque vestibulum semper metus vel molestie  lobortis sollicituding.</p>
                          </div>
                        </div>
                      </div>
                    </li>
                  </ul>
                </li>
                <li class="dropdown"><a href="portfolio-one.html" class="dropdown-toggle">Portfolio</a>
                  <ul role="menu" class="dropdown-menu">
                    <li> <a href="portfolio-one.html">Single Item</a> </li>
                    <li> <a href="portfolio-two.html">Portfolio Columns 2</a> </li>
                    <li> <a href="portfolio-three.html">Portfolio Columns 3</a> </li>
                    <li> <a href="portfolio-four.html">Portfolio Columns 4</a> </li>
                    <li> <a href="portfolio-five.html">Portfolio + Sidebar</a> </li>
                    <li> <a href="portfolio-six.html">Portfolio Full Width</a> </li>
                    <li> <a href="portfolio-seven.html">Portfolio Masonry</a> </li>
                    <li> <a href="portfolio-eight.html">Masonry Projects</a> </li>
                    <li> <a href="portfolio-nine.html">Slider Projects</a> </li>
                  </ul>
                </li>
                <li class="dropdown"><a href="blog.html" class="dropdown-toggle">Blog</a>
                  <ul role="menu" class="dropdown-menu">
                    <li><a href="blog.html"> Blog Full Width</a> </li>
                    <li><a href="blog2.html"> Blog 3Columns</a> </li>
                    <li><a href="blog3.html"> Blog Standard</a> </li>
                    <li><a href="blog-post.html"> Single Post</a> </li>
                  </ul>
                </li>
                <li class="dropdown"><a href="contact.php" class="dropdown-toggle active">Contact</a>
                  <ul role="menu" class="dropdown-menu right-margin">
                    <li><a href="contact.php"> Contact Variation 1</a> </li>
                    <li><a href="contact2.php"> Contact Variation 2</a> </li>
                    <li><a href="contact3.php"> Contact Variation 3</a> </li>
                  </ul>
                </li>
              </ul>
            </nav>
          </div>
        </div>
      </div>
    </div>
  </header>
  <!-- end Header -->
  
  <div class="page-header five">
    <div class="container">
      <div class="col-md-6 left-padd0 m-bottom2">
        <h2 class="uppercase font-thin font-white font30 m-bottom1">Contact Style 3</h2>
        <h4 class="font-white font18">Get in Touch with Us</h4>
      </div>
      <div class="col-md-6">
        <div class="breadcrumbs view-links"><a href="index.html">Home</a> <i>/</i> <a href="#">Contact</a> <i>/</i> Contact Style 3</div>
      </div>
    </div>
  </div>
  <!-- end features section 1 -->
  
  <div class="section-lg m-top0">
  <div class="embed-container maps">
    <iframe width="425" height="450" class="fullwide-col" src="https://maps.google.co.in/maps?sll=34.0204989,-118.4117325&amp;sspn=0.8745562,1.4073488&amp;cid=16298491244936825076&amp;q=Los+Angeles,+CA,+USA&amp;ie=UTF8&amp;hq=&amp;hnear=Los+Angeles,+Los+Angeles+County,+California,+United+States&amp;t=m&amp;ll=34.052234,-118.243685&amp;spn=0.697085,0.848982&amp;output=embed" style="pointer-events: none;"></iframe>
  </div>
</div>

<div class="section-lg m-top8">
  <div class="container">
    <div class="row">
      <div class="col-md-8">
        <form action="demo-contacts-process.php" method="post" id="sky-form" class="sky-form">
				<fieldset>					
					<div class="row">
						<section class="col col-6">
							<label class="label">Name</label>
							<label class="input">
								<i class="icon-append fa fa-user"></i>
								<input type="text" name="name" id="name">
							</label>
						</section>
						<section class="col col-6">
							<label class="label">E-mail</label>
							<label class="input">
								<i class="icon-append fa fa-envelope-o"></i>
								<input type="email" name="email" id="email">
							</label>
						</section>
					</div>
					
					<section>
						<label class="label">Subject</label>
						<label class="input">
							<i class="icon-append fa fa-tag"></i>
							<input type="text" name="subject" id="subject">
						</label>
					</section>
					
					<section>
						<label class="label">Message</label>
						<label class="textarea">
							<i class="icon-append fa fa-comment"></i>
							<textarea rows="4" name="message" id="message"></textarea>
						</label>
					</section>
					
					<section>
						<label class="label">Enter characters below:</label>
						<label class="input input-captcha">
							<img src="captcha/image.php?1720794239" width="100" height="35" alt="Captcha image" />
							<input type="text" maxlength="6" name="captcha" id="captcha">
						</label>
					</section>
					
					<section>
						<label class="checkbox"><input type="checkbox" name="copy"><i></i>Send a copy to my e-mail address</label>
					</section>
				</fieldset>
				
				<footer>
					<button type="submit" class="button">Send message</button>
				</footer>
				
				<div class="message">
					<i class="fa fa-check"></i>
					<p>Your message was successfully sent!</p>
				</div>
			</form>
      </div>
      <div class="col-md-4">
        <div class="address-info">
          <h2 class="m-bottom2">Address Info</h2>
          <p>Feel free to talk to our online representative at any time you please using our Live Chat system on our website or one of the below instant messaging programs.</p>
          <br>
          <p>Please be patient while waiting for response.<br>
<strong>Phone General Inquiries: +1 (012) 345 6789</strong></p>
          <br>
        </div>
        <!-- end section -->
        
        <div class="address-info">
          <h2 class="m-bottom2">Address Info Two</h2>
          <ul class="address-info map">
            <li><i class="fa fa-map-marker"></i> 15 Barnes Wallis Way, 358744, USA</li>
            <li><i class="fa fa-phone"></i> +1 (012) 345 6789</li>
            <li><i class="fa fa-envelope"></i> info@yourdomain.com</li>
          </ul>
        </div>
        <!-- end section --> 
      </div>
    </div>
  </div>
</div>
  <!-- end features section 2 -->
 
  <footer class="footer-bg texture1 m-top8">
    <div class="container">
      <div class="row">
        <div class="col-md-3 col-sm-12 font-grey">
          <h4 class="font16 font-thin uppercase font-white">About Company</h4>
          <div class="title-line color"></div>
          <p class="m-bottom3">Pellentesque mi purus, eleifend sedt commodo vel, sagittis elts vestibulum dui sagittis mlste sagittis elts.</p>
          <ul class="address-info listitems">
            <li><i class="fa fa-map-marker"></i> 15 Barnes Wallis Way, 358744, USA</li>
            <li><i class="fa fa-phone"></i> +1 (012) 345 6789</li>
            <li><i class="fa fa-envelope"></i> info@yourdomain.com</li>
          </ul>
        </div>
        <div class="col-md-3 col-sm-12 font-grey">
          <h4 class="font16 font-thin uppercase font-white">Support</h4>
          <div class="title-line color"></div>
          <ul class="listitems left-padd0">
            <li><a href="#"><i class="fa fa-angle-right"></i> Product Support</a></li>
            <li><a href="#"><i class="fa fa-angle-right"></i> Report Abuse</a></li>
            <li><a href="#"><i class="fa fa-angle-right"></i> Knowledgebase</a></li>
            <li><a href="#"><i class="fa fa-angle-right"></i> Affiliates and Resellers</a></li>
            <li><a href="#"><i class="fa fa-angle-right"></i> WHOIS Search</a></li>
            <li><a href="#"><i class="fa fa-angle-right"></i> Scripting &amp; Add-ons</a></li>
          </ul>
        </div>
        <div class="col-md-3 col-sm-12 font-grey">
          <h4 class="font16 font-thin uppercase font-white">Resources</h4>
          <div class="title-line color"></div>
          <ul class="listitems left-padd0">
            <li><a href="#"><i class="fa fa-angle-right"></i> Email Services</a></li>
            <li><a href="#"><i class="fa fa-angle-right"></i> WHOIS Search</a></li>
            <li><a href="#"><i class="fa fa-angle-right"></i> Scripting &amp; Add-ons</a></li>
            <li><a href="#"><i class="fa fa-angle-right"></i> Marketing Services</a></li>
            <li><a href="#"><i class="fa fa-angle-right"></i> Affiliates</a></li>
            <li><a href="#"><i class="fa fa-angle-right"></i> Scripting &amp; Add-ons</a></li>
          </ul>
        </div>
        <div class="col-md-3 col-sm-12 font-grey">
          <h4 class="font16 font-thin uppercase font-white">Account</h4>
          <div class="title-line color"></div>
          <ul class="listitems left-padd0">
            <li><a href="#"><i class="fa fa-angle-right"></i> My Account</a></li>
            <li><a href="#"><i class="fa fa-angle-right"></i> My Renewals</a></li>
            <li><a href="#"><i class="fa fa-angle-right"></i> Create Account</a></li>
            <li><a href="#"><i class="fa fa-angle-right"></i> Knowledgebase</a></li>
            <li><a href="#"><i class="fa fa-angle-right"></i> Contact Us</a></li>
            <li><a href="#"><i class="fa fa-angle-right"></i> Affiliates and Resellers</a></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="container">
      <div class="col-md-6 nopadding m-top5">
        <h5 class="font-white m-bottom1">Find Us on</h5>
        <img src="images/site-img8.jpg" alt=""> <img src="images/site-img9.jpg" alt=""> </div>
      <div class="col-md-6 nopadding m-top5">
        <h5 class="font-white m-bottom1">Sign up for Special Offers!</h5>
        <form method="get" id="newsletter" action="index.html">
          <input class="input-text newsfield" name="dsearch" id="newslette" value="Enter your Name here..." onFocus="if (this.value == 'Enter your Domain Name here...') {this.value = '';}" onBlur="if (this.value == '') {this.value = 'Enter your Domain Name here...';}" type="text" />
          <input id="submits" value="SUBMIT" type="submit" class="btn orange-button two uppercase font-bold"/>
        </form>
      </div>
    </div>
  </footer>
  <div class="copyrights black-bg">
    <div class="container">
      <div class="row">
        <div class="col-md-6 m-top1 m-bottom1"> Copyright &copy; 2016 yourdomian. All rights reserved. </div>
        <div class="col-md-6">
          <ul class="social-icons style-three">
            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
            <li><a href="#"><i class="fa fa-flickr"></i></a></li>
            <li><a href="#"><i class="fa fa-youtube"></i></a></li>
            <li><a href="#"><i class="fa fa-vimeo-square"></i></a></li>
            <li><a href="#"><i class="fa fa-rss"></i></a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <!-- end footer --> 
  
</div>
<!-- site wrapper end --> 

<!-- style switcher --> 
<script type="text/javascript" src="js/style-switcher/styleswitcher.js"></script>
<div id="style-selector">
  <div class="style-selector-wrapper"> <span class="title">Choose Theme Options</span>
    <div> <span class="title-sub2">Choose Layout</span>
      <div class="styles">
        <ul class="layout-style">
          <li><a href="index.html" class="btn btn-default black">Wide</a></li>
          <li><a href="boxed/index.html" class="btn btn-default black">Boxed</a></li>
        </ul>
      </div>
      <span class="title-sub2">Predefined Color Skins</span>
      <ul class="styles">
        <li><a href="#" onClick="setActiveStyleSheet('green'); return false;" title="Green"><span class="pre-color-skin10"></span></a></li>
        <li><a href="#" onClick="setActiveStyleSheet('orange'); return false;" title="Orange"><span class="pre-color-skin1"></span></a></li>
        <li><a href="#" onClick="setActiveStyleSheet('blue'); return false;" title="Blue"><span class="pre-color-skin2"></span></a></li>
        <li><a href="#" onClick="setActiveStyleSheet('lightgreen'); return false;" title="Light Green"><span class="pre-color-skin3"></span></a></li>
        <li><a href="#" onClick="setActiveStyleSheet('lightblue'); return false;" title="Light Blue"><span class="pre-color-skin4"></span></a></li>
        <li><a href="#" onClick="setActiveStyleSheet('sea'); return false;" title="Sea"><span class="pre-color-skin5"></span></a></li>
        <li><a href="#" onClick="setActiveStyleSheet('lightred'); return false;" title="Light Red"><span class="pre-color-skin6"></span></a></li>
        <li><a href="#" onClick="setActiveStyleSheet('bluesea'); return false;" title="Blue Sea"><span class="pre-color-skin7"></span></a></li>
        <li><a href="#" onClick="setActiveStyleSheet('red'); return false;" title="Red"><span class="pre-color-skin8"></span></a></li>
        <li><a href="#" onClick="setActiveStyleSheet('lightorange'); return false;" title="Light Orange"><span class="pre-color-skin9"></span></a></li>
      </ul>
      <!-- end Predefined Color Skins --> 
      
      <span class="title-sub2">BG Patterns for Boxed</span>
      <ul class="styles noborrder">
        <li><a href="#" onClick="setActiveStyleSheet('pattern-default'); return false;"><span class="bg-patterns1"></span></a></li>
        <li><a href="#" onClick="setActiveStyleSheet('pattern-one'); return false;"><span class="bg-patterns2"></span></a></li>
        <li><a href="#" onClick="setActiveStyleSheet('pattern-two'); return false;"><span class="bg-patterns3"></span></a></li>
        <li><a href="#" onClick="setActiveStyleSheet('pattern-three'); return false;"><span class="bg-patterns4"></span></a></li>
        <li><a href="#" onClick="setActiveStyleSheet('pattern-four'); return false;"><span class="bg-patterns5"></span></a></li>
        <li><a href="#" onClick="setActiveStyleSheet('pattern-five'); return false;"><span class="bg-patterns6"></span></a></li>
        <li><a href="#" onClick="setActiveStyleSheet('pattern-six'); return false;"><span class="bg-patterns7"></span></a></li>
        <li><a href="#" onClick="setActiveStyleSheet('pattern-seven'); return false;"><span class="bg-patterns8"></span></a></li>
        <li><a href="#" onClick="setActiveStyleSheet('pattern-eight'); return false;"><span class="bg-patterns9"></span></a></li>
        <li><a href="#" onClick="setActiveStyleSheet('pattern-nine'); return false;"><span class="bg-patterns10"></span></a></li>
        <li><a href="#" onClick="setActiveStyleSheet('pattern-ten'); return false;"><span class="bg-patterns11"></span></a></li>
        <li><a href="#" onClick="setActiveStyleSheet('pattern-eleven'); return false;"><span class="bg-patterns12"></span></a></li>
        <li><a href="#" onClick="setActiveStyleSheet('pattern-twelve'); return false;"><span class="bg-patterns13"></span></a></li>
        <li><a href="#" onClick="setActiveStyleSheet('pattern-thirteen'); return false;"><span class="bg-patterns14"></span></a></li>
        <li><a href="#" onClick="setActiveStyleSheet('pattern-fourteen'); return false;"><span class="bg-patterns15"></span></a></li>
      </ul>
      <!-- end BG Patterns --> 
      
      <a href="#" class="close icon-chevron-right"><i class="fa fa-wrench"></i></a></div>
  </div>
</div>
<!-- end style switcher --> 

<a href="#" class="scrollup"></a> 
<!-- end scroll to top of the page--> 

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="js/jquery.min.js"></script> 

<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="js/jquery.js"></script> 
<script src="js/bootstrap.min.js"></script> 

<!-- Main Menu -->
<script src="js/mainmenu/customeUI.js"></script> 
<script src="js/mainmenu/jquery.sticky.js"></script>

<!-- Style Switcher --> 
<script src="js/style-switcher/jquery-1.js"></script> 
<script src="js/style-switcher/styleselector.js"></script> 

<!-- Scroll to Fixied Sticky --> 
<script src="js/mainmenu/sticky.js" type="text/javascript"></script> 

<!-- contact form --> 
<script src="js/form/jquery.form.min.js"></script> 
<script src="js/form/jquery.validate.min.js"></script>
<script type="text/javascript">
(function($) {
  "use strict";
	$(function()
			{
				// Validation
				$("#sky-form").validate(
				{					
					// Rules for form validation
					rules:
					{
						name:
						{
							required: true
						},
						email:
						{
							required: true,
							email: true
						},
						message:
						{
							required: true,
							minlength: 10
						},
						captcha:
						{
							required: true,
							remote: 'captcha/process.php'
						}
					},
										
					// Messages for form validation
					messages:
					{
						name:
						{
							required: 'Please enter your name',
						},
						email:
						{
							required: 'Please enter your email address',
							email: 'Please enter a VALID email address'
						},
						message:
						{
							required: 'Please enter your message'
						},
						captcha:
						{
							required: 'Please enter characters',
							remote: 'Correct captcha is required'
						}
					},
										
					// Ajax form submition					
					submitHandler: function(form)
					{
						$(form).ajaxSubmit(
						{
							beforeSend: function()
							{
								$('#sky-form button[type="submit"]').attr('disabled', true);
							},
							success: function()
							{
								$("#sky-form").addClass('submited');
							}
						});
					},
					
					// Do not change code below
					errorPlacement: function(error, element)
					{
						error.insertAfter(element.parent());
					}
				});
			});
			})(jQuery);		
		</script> 

<!-- Scroll Up --> 
<script src="js/scrolltotop/totop.js" type="text/javascript"></script>
<!-- Google Analytics --> 
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-90131544-1', 'auto');
  ga('send', 'pageview');

</script>
</body>
</html>